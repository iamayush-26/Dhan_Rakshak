import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, ArrowDownLeft, MoreHorizontal } from "lucide-react";

interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: "income" | "expense";
  category: string;
  date: string;
}

const mockTransactions: Transaction[] = [
  {
    id: "1",
    description: "Salary Deposit",
    amount: 3500,
    type: "income",
    category: "Salary",
    date: "2024-01-15"
  },
  {
    id: "2",
    description: "Grocery Shopping",
    amount: -125.50,
    type: "expense",
    category: "Food",
    date: "2024-01-14"
  },
  {
    id: "3",
    description: "Electric Bill",
    amount: -89.00,
    type: "expense",
    category: "Utilities",
    date: "2024-01-13"
  },
  {
    id: "4",
    description: "Freelance Project",
    amount: 750,
    type: "income",
    category: "Freelance",
    date: "2024-01-12"
  },
  {
    id: "5",
    description: "Coffee Shop",
    amount: -12.50,
    type: "expense",
    category: "Food",
    date: "2024-01-11"
  }
];

const RecentTransactions = () => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(Math.abs(value));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card className="animate-slide-up">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
        <Button variant="ghost" size="sm" className="text-primary">
          View All
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {mockTransactions.map((transaction) => (
          <div 
            key={transaction.id}
            className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-full ${
                transaction.type === "income" 
                  ? "bg-success-light text-success" 
                  : "bg-accent text-accent-foreground"
              }`}>
                {transaction.type === "income" ? (
                  <ArrowUpRight className="h-4 w-4" />
                ) : (
                  <ArrowDownLeft className="h-4 w-4" />
                )}
              </div>
              <div>
                <p className="font-medium text-foreground">{transaction.description}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge 
                    variant="secondary" 
                    className="text-xs"
                  >
                    {transaction.category}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {formatDate(transaction.date)}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`font-semibold ${
                transaction.type === "income" 
                  ? "text-success" 
                  : "text-foreground"
              }`}>
                {transaction.type === "income" ? "+" : "-"}{formatCurrency(transaction.amount)}
              </span>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default RecentTransactions;