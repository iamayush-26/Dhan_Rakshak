import Navigation from "@/components/layout/Navigation";
import AddTransactionForm from "@/components/forms/AddTransactionForm";

const AddTransaction = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Add Transaction</h1>
          <p className="text-muted-foreground">Track your income and expenses to stay on top of your finances</p>
        </div>
        
        <AddTransactionForm />
      </div>
    </div>
  );
};

export default AddTransaction;