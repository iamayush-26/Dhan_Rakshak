import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BalanceCard from "@/components/dashboard/BalanceCard";
import RecentTransactions from "@/components/dashboard/RecentTransactions";
import Navigation from "@/components/layout/Navigation";
import { TrendingUp, DollarSign, PiggyBank, Target } from "lucide-react";
import financeHero from "@/assets/finance-hero.jpg";
const Dashboard = () => {
  return <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-background/40" />
        <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: `url(${financeHero})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }} />
        <div className="relative container mx-auto px-4 py-12">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 animate-fade-in">Welcome back, Ayan</h1>
            <p className="text-xl text-muted-foreground animate-slide-up">
              Here's what's happening with your money today
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Balance Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <BalanceCard title="Total Balance" amount={12450.75} change={8.2} changeType="increase" icon={<DollarSign className="h-4 w-4" />} />
          <BalanceCard title="Monthly Income" amount={4200.00} change={12.5} changeType="increase" icon={<TrendingUp className="h-4 w-4" />} />
          <BalanceCard title="Monthly Expenses" amount={2850.50} change={-3.2} changeType="decrease" icon={<Target className="h-4 w-4" />} />
          <BalanceCard title="Savings Goal" amount={8500.00} change={15.8} changeType="increase" icon={<PiggyBank className="h-4 w-4" />} />
        </div>

        {/* Charts and Recent Transactions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Income vs Expenses Chart */}
          <div className="lg:col-span-2">
            <Card className="animate-slide-up">
              <CardHeader>
                <CardTitle>Income vs Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gradient-to-br from-primary/5 to-secondary/5 rounded-lg flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <TrendingUp className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>Chart visualization would appear here</p>
                    <p className="text-sm">Interactive charts showing your financial trends</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Transactions */}
          <div>
            <RecentTransactions />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card className="animate-fade-in">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <button className="p-4 rounded-lg border hover:bg-muted/50 transition-colors text-center group">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <DollarSign className="h-4 w-4 text-primary" />
                  </div>
                  <p className="text-sm font-medium">Add Income</p>
                </button>
                
                <button className="p-4 rounded-lg border hover:bg-muted/50 transition-colors text-center group">
                  <div className="w-8 h-8 bg-accent/20 rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:bg-accent/30 transition-colors">
                    <Target className="h-4 w-4 text-accent-dark" />
                  </div>
                  <p className="text-sm font-medium">Add Expense</p>
                </button>
                
                <button className="p-4 rounded-lg border hover:bg-muted/50 transition-colors text-center group">
                  <div className="w-8 h-8 bg-secondary/10 rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:bg-secondary/20 transition-colors">
                    <PiggyBank className="h-4 w-4 text-secondary" />
                  </div>
                  <p className="text-sm font-medium">Set Goal</p>
                </button>
                
                <button className="p-4 rounded-lg border hover:bg-muted/50 transition-colors text-center group">
                  <div className="w-8 h-8 bg-muted rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:bg-muted/80 transition-colors">
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-sm font-medium">View Reports</p>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>;
};
export default Dashboard;